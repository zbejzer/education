# pomocniczy plik 5
def normalize(text):
    return text.strip().lower()
