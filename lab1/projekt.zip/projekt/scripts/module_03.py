# pomocniczy plik 3
def is_even(n):
    return n % 2 == 0
