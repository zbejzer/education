# pomocniczy plik 6
def add(a, b):
    return a + b
