# pomocniczy plik 1
def add(a, b):
    return a + b
