# pomocniczy plik 7
def multiply(a, b):
    return a * b
