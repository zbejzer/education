# pomocniczy plik 8
def is_even(n):
    return n % 2 == 0
