from config.settings import DEBUG_MODE

def main():
    if DEBUG_MODE:
        print("Program uruchomiony w trybie DEBUG")
    else:
        print("Program uruchomiony poprawnie")

if __name__ == "__main__":
    main()
